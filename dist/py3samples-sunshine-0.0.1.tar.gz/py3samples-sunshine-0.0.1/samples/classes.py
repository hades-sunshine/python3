class SampleClass:
    x = 5

    def __init__(self, x):
        self.x = x

    def print(self):
        print(self.x)


